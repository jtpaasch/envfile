Envfile
=======

Loads/unloads environment variables from a ``.env`` file.


