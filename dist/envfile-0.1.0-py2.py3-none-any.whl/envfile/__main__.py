# -*- coding: utf-8 -*-

"""The ``__main__`` module of the ``envfile`` package.

The only thing that needs to happen here is to start the application,
which is done by calling the application's ``main()`` function.

"""

from envfile.application import main
main()

